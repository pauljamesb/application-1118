﻿// refs
// https://docs.microsoft.com/en-us/aspnet/mvc/overview/getting-started/introduction/adding-a-view

using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MMAppMVC.Data;
using MMAppMVC.Models;

namespace MMAppMVC.Controllers
{
    public class ItemsController : Controller
    {

        private readonly ApplicationDbContext _db;
        public ItemsController(ApplicationDbContext db)
        {
            _db = db;
        }


        public IActionResult Index()
        {
            ViewBag.Message = "Hello";
            ViewBag.TotalAmount = AddAllItems();
            return View(_db.Items.ToList());
        }



        // Move to services class
        // Services/Service.cs
        // Calculation could go here
        public int AddAllItems()
        {
            var total = 0;
            foreach(var el in _db.Items)
            {
                // logic
                total = total + el.Amount;
            }
            return total;
        }





        // Create items
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Item item)
        {
            if (ModelState.IsValid)
            {
                _db.Add(item);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(item);
        }




        // Delete items
        public async Task<IActionResult> Delete(int? Id)
        {
            if (Id == null)
            {
              return NotFound();
            }

            var itemToDelete = _db.Items.FindAsync(Id);
            if(itemToDelete == null)
            {
                  retrun NotFound();
            }

            return View(itemToDelete);
        }


        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed()
        {
            var itemToDelete = _db.Items.FindAsync(Id);
            _db.Items.Remove(itemToDelete);
            await _db.SaveChangesAsync();
            return RedirectToAction("Index");
        }



        // Edit
        public async Task<IActionResult> Edit(int? Id)
        {
            if (Id == null)
            {
              return NotFound();
            }

            var itemToEdit = await _db.Items.FindAsync(Id);

            if(itemToEdit == null)
            {
              return NotFound();
            }

            return View(itemToEdit);

        }










        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Item item)
        {
            if (id != item.Id)
            {
                return NotFound();
            }

            if(ModelState.IsValid)
            {
                _db.Update(item);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(item);
        }
























    }
}
